---
name: Digital Adda
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fea619'
  on-secondary-container: '#684000'
  tertiary: '#005338'
  on-tertiary: '#ffffff'
  tertiary-container: '#006e4b'
  on-tertiary-container: '#67f4b7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '800'
    lineHeight: 3.5rem
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies the warmth, camaraderie, and spirited intellectual energy of a modern academic hub—a digital campus square where students gather to discover, exchange, and elevate study materials. It bridges the gap between structured academic discipline and youthful, informal collaboration. 

The aesthetic is clean, energetic, and deeply trustworthy. It rejects chaotic student forum tropes in favor of an organized, elevated editorial layout paired with tactile micro-interactions, high-legibility typographic scannability, and lively visual accents. The emotional goal is clarity and encouragement: transforming the stress of exam prep into an empowering, collaborative social ritual.

## Colors

The palette balances authoritative scholarly tones with warm, optimistic accents:

- **Primary (`#4F46E5` / Deep Indigo)**: Drives the core interface landmarks, primary actions, and focused study states. It conveys structural integrity and focus. An active deep-tone variant (`#4338CA`) handles pressed and hover states.
- **Secondary (`#F59E0B` / Warm Amber)**: Serves as the energetic spark—used for bookmarking, badges, pro-tips, high-value highlights, and community kudos.
- **Tertiary (`#10B981` / Emerald)**: Signals verified notes, peer-reviewed accuracy, successful uploads, and passing milestones.
- **Neutrals (`#0F172A`, `#334155`, `#64748B`)**: Deliver high-contrast, fatigue-free reading across prolonged study sessions. Background canvases utilize soft slate tints (`#F8FAFC`, `#F1F5F9`) layered beneath crisp `#FFFFFF` cards to provide clean visual segmentation.

## Typography

The typographic hierarchy leverages **Plus Jakarta Sans** for expressive, geometric, and modern display headers and navigational labels, giving the platform its vibrant, youthful tone. Body text uses **Inter** to ensure maximum legibility, neutral clarity, and comfort during long reading sessions of dense academic syllabi, summaries, and peer feedback.

Maintain strict letter-spacing rules: tighter tracking on headings (`-0.01em` to `-0.03em`) creates a punchy editorial look, while slight positive tracking on uppercase pill labels (`0.02em` to `0.04em`) ensures crisp readability at small scales.

## Layout & Spacing

The layout is built on a responsive 12-column fluid grid system configured to handle card-dense feeds, document previews, and side navigation.

- **Desktop (≥ 1024px)**: 12-column grid, 24px (`1.5rem`) gutters, dynamic page margins with a max content container width of `1280px`. Left sidebar (280px fixed) handles persistent subject filters and community directories.
- **Tablet (768px - 1023px)**: 8-column grid, 20px gutters, 24px margins. Navigation collapses to a top app bar with horizontal scrolling category rails.
- **Mobile (< 768px)**: 4-column grid, 16px (`1rem`) gutters, 16px margins. Note cards take full width with compact vertical stacks.

All content components follow an 8pt spatial rhythm. Structural gaps between distinct card sections use `space-xl` (`2.5rem`), while internal note metadata elements rely on `space-xs` and `space-sm`.

## Elevation & Depth

Visual hierarchy uses a refined blend of subtle surface contrast and diffuse ambient drop shadows to maintain an airy, clutter-free desk surface:

- **Level 0 (Canvas)**: Background base `#F8FAFC`. Zero elevation.
- **Level 1 (Cards & Panels)**: `#FFFFFF` surface with a delicate, dual-layer shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.04)` and a 1px border of `#F1F5F9`.
- **Level 2 (Interactive Cards / Hover States)**: `0 10px 15px -3px rgba(79, 70, 229, 0.06), 0 4px 6px -4px rgba(15, 23, 42, 0.04)`, translated upward by 2px to signal affordance.
- **Level 3 (Modals, Overlays & Popovers)**: Elevated dropdowns and reader drawers use `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.03)` with a neutral backdrop scrim (`rgba(15, 23, 42, 0.4)` with 4px backdrop blur).

## Shapes

The design system adopts a welcoming and friendly radius standard (`roundedness: 2`):

- **Base Radius (`0.5rem` / 8px)**: Inputs, small buttons, and internal thumbnail viewports.
- **Medium Radius (`0.75rem` - `1rem` / 12px - 16px)**: Primary note cards, resource containers, modal panels, and study deck previews.
- **Pill Radius (`9999px`)**: Interactive subject tags, status badges, counter chips, avatar indicators, and floating action triggers.

## Components

### Buttons
- **Primary**: Solid Indigo (`#4F46E5`), white text, `rounded-md` (8px) to `rounded-lg` (12px), bold label styling (`label-lg`), with subtle lift on hover and `#4338CA` active background.
- **Secondary**: Tinted surface (`#EEF2FF`), text `#4F46E5`. Hover transitions to `#E0E7FF`.
- **Outline / Ghost**: 1px `#E2E8F0` border, text `#334155`, transparent fill; turns to `#F8FAFC` on hover.
- **Icon / Upvote**: Pill-shaped or soft-square toggle with dual-state color: neutral slate when inactive, shifting to glowing amber (`#FEF3C7` fill, `#D97706` icon/text) upon interaction.

### Chips & Subject Tags
- Interactive filters and category tags feature full pill radiuses (`rounded-full`), padded `0.375rem 0.875rem`.
- Inactive tags utilize `#F1F5F9` background with `#475569` text.
- Active semester/subject tags shift to `#4F46E5` fill with `#FFFFFF` text or soft theme-tinted badges (e.g., `#ECFDF5` with `#059669` text for verified engineering or medical modules).

### Note Cards
- Constructed with `#FFFFFF` background, 16px border-radius, and 1px border in `#E2E8F0`.
- Includes a crisp upper metadata ribbon: uploader avatar, university badge, date stamp, and download count.
- Main body features truncated document title (`headline-sm`), subject chip, and file-type indicator (PDF, Hand-written, LaTeX).
- Bottom action bar: upvote counter, save-to-deck bookmark icon, and quick preview button.

### Form Inputs & Search
- Inputs feature `0.75rem` radius, 1px `#CBD5E1` border, `#FFFFFF` surface, and `#0F172A` text.
- Focused state applies a sharp 2px outline of `#4F46E5` with an accompanying subtle glow (`box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15)`).
- Search fields integrate clean inline icon prefixes (magnifying glass) and quick keyboard shortcut pills (`⌘K`).

### Checkboxes & Radio Buttons
- Rounded squares (4px) for checkboxes and full circles for radios. Checked state fills with `#4F46E5` sporting a clean white check/dot icon.